package com.cg.mobilebilling.services;

import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;
import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.daoservices.BillingDAOServices;
import com.cg.mobilebilling.daoservices.CustomerDAOServices;
import com.cg.mobilebilling.daoservices.PlanDAOServices;
import com.cg.mobilebilling.daoservices.PostpaidAccountDAOServices;
import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
@Component("billingServices")
@Transactional
public class BillingServicesImpl implements BillingServices {

	@Autowired
	private CustomerDAOServices customerDAOServices;
	@Autowired
	private PostpaidAccountDAOServices postpaidAccountDAOServices;
	@Autowired
	private PlanDAOServices planDAOServices;
	@Autowired
	private BillingDAOServices billingDAOServices;
	private PostpaidAccount postpaidAccount;
	private Plan plan;
	private Customer customer;
	private Bill bill;
	private List<Customer> customers;
	private Map<Long, PostpaidAccount> postpaidAccounts;

	@Override
	public List<Plan> getPlanAllDetails() throws BillingServicesDownException {
		return planDAOServices.findAll();
	}

	@Override
	public Customer acceptCustomerDetails(Customer customer)
			throws BillingServicesDownException, CustomerDetailsNotFoundException {
		Plan plan=new Plan(101, 200, 100, 50, 100, 20, 1, 1, 1, 1, 1, 100, "Punjab", "Silver");
		Plan plan1=new Plan(102, 300, 200, 150, 200, 30, 2, 2, 2, 2, 2, 200, "Maharashtra", "Gold");
		Plan plan2=new Plan(103, 400, 300, 250, 300, 40, 3, 3, 3, 3, 3, 300, "Delhi", "Platinum");
		planDAOServices.save(plan);
		planDAOServices.save(plan1);
		planDAOServices.save(plan2);
		return customerDAOServices.save(customer);		
	}

	@Override
	public long openPostpaidMobileAccount(int customerID, int planID)
			throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException {
		Customer customer =customerDAOServices.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("CustomerDetailsNotFoundException"));
		Plan plan= planDAOServices.findById(planID).orElseThrow(()-> new PlanDetailsNotFoundException("PlanDetailsNotFoundException"));
		PostpaidAccount account = new PostpaidAccount(customer,plan);
		account=postpaidAccountDAOServices.save(account);
		return account.getMobileNo();
	}

	/*@Override
	public float generateMonthlyMobileBill(int customerID, long mobileNo, String billMonth, int noOfLocalSMS,
			int noOfStdSMS, int noOfLocalCalls, int noOfStdCalls, int internetDataUsageUnits)
					throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
					BillingServicesDownException, PlanDetailsNotFoundException {
		PostpaidAccount postpaidAccount=postpaidAccountDAOServices.findById(mobileNo).get();
		Plan plan=planDAOServices.findById(postpaidAccount.getPlan().getPlanID()).get();
		noOfLocalCalls-=plan.getFreeLocalCalls();
		noOfLocalSMS-=plan.getFreeLocalSMS();
		noOfStdCalls-=plan.getFreeStdCalls();
		noOfStdSMS-=plan.getFreeStdSMS();
		Float localSMSAmount=noOfLocalSMS*plan.getLocalSMSRate(),stdSMSAmount=noOfStdSMS*plan.getStdSMSRate(),localCallAmount=noOfLocalCalls*plan.getLocalCallRate(),stdCallAmount=noOfStdCalls*plan.getStdCallRate(),internetDataUsageAmount=internetDataUsageUnits*plan.getInternetDataUsageRate();
		Float totalAmount=localCallAmount+localSMSAmount+stdCallAmount+stdSMSAmount+internetDataUsageAmount+plan.getMonthlyRental()+100+50;
		Bill bill =new Bill(noOfLocalSMS, noOfStdSMS, noOfLocalCalls, noOfStdCalls, internetDataUsageUnits, billMonth, totalAmount, localSMSAmount, stdSMSAmount, localCallAmount, stdCallAmount, internetDataUsageAmount, 100, 50, postpaidAccount);
		billingDAOServices.save(bill);
		return totalAmount;
	}*/

	@Override
	public Bill generateMonthlyMobileBill(int customerID, long mobileNo, String billMonth, int noOfLocalSMS,
			int noOfStdSMS, int noOfLocalCalls, int noOfStdCalls, int internetDataUsageUnits)
					throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
					BillingServicesDownException, PlanDetailsNotFoundException {
		Customer customer=customerDAOServices.findById(customerID).orElseThrow(()->
		new CustomerDetailsNotFoundException("Customer details for customerId"+customerID+"not found"));
		PostpaidAccount postpaidAccount=postpaidAccountDAOServices.findById(mobileNo).orElseThrow(()->
		new PostpaidAccountNotFoundException("Postpaid account for mobileNo"+mobileNo+"not found"));
		plan = postpaidAccount.getPlan();
		float localSMSAmount=plan.getLocalSMSRate()*java.lang.Math.abs(noOfLocalSMS-plan.getFreeLocalSMS()),
				stdSMSAmount=plan.getStdSMSRate()*java.lang.Math.abs(noOfStdSMS-plan.getFreeStdSMS()),
				localCallAmount=plan.getLocalCallRate()*java.lang.Math.abs(noOfLocalCalls-plan.getFreeLocalCalls()),
				stdCallAmount=plan.getStdCallRate()*java.lang.Math.abs(noOfStdCalls-plan.getFreeStdCalls()),
				internetDataUsageAmount=plan.getInternetDataUsageRate()*java.lang.Math.abs(internetDataUsageUnits-plan.getFreeInternetDataUsageUnits());
		float totalBillAmount=localCallAmount+stdCallAmount+localSMSAmount+stdSMSAmount+internetDataUsageAmount+plan.getMonthlyRental();
		bill=new Bill(noOfLocalSMS, noOfStdSMS, noOfLocalCalls, noOfStdCalls, internetDataUsageUnits, billMonth, totalBillAmount, localSMSAmount, stdSMSAmount, localCallAmount, stdCallAmount, internetDataUsageAmount, 0, 0, postpaidAccount);
		billingDAOServices.save(bill);
		return bill;
	}

	@Override
	public Customer getCustomerDetails(Customer customer)
			throws CustomerDetailsNotFoundException, BillingServicesDownException {
		Customer customer1=customerDAOServices.findById(customer.getCustomerID()).orElseThrow(()->new CustomerDetailsNotFoundException("Customer Details Not Found"));
		if (!customer.getFirstName().equals(customer1.getFirstName())) 
			throw new CustomerDetailsNotFoundException("Customer Details Not Found");
		return customer1;
	}

	@Override
	public List<Customer> getAllCustomerDetails() throws BillingServicesDownException {
		List<Customer> customers=customerDAOServices.findAll();
		return customers;
	}

	@Override
	public PostpaidAccount getPostPaidAccountDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		Customer customer=customerDAOServices.findById(customerID).orElseThrow(()->
		new CustomerDetailsNotFoundException("Customer details for customerId"+customerID+"not found"));
		PostpaidAccount postpaidAccount=postpaidAccountDAOServices.findById(mobileNo).orElseThrow(()->
		new PostpaidAccountNotFoundException("Postpaid account for mobileNo"+mobileNo+"not found"));
		return postpaidAccount;
	}

	@Override
	public Map<Long, PostpaidAccount> getCustomerAllPostpaidAccountsDetails(int customerID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException {
		Customer customer=customerDAOServices.findById(customerID).orElseThrow(()->
		new CustomerDetailsNotFoundException("Customer details for customerId"+customerID+"not found"));
		Map<Long, PostpaidAccount> postpaidAccounts = customer.getPostpaidAccounts();
		return postpaidAccounts;
	}

	@Override
	public Bill getMobileBillDetails(int customerID, long mobileNo, String billMonth)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillDetailsNotFoundException, BillingServicesDownException, PlanDetailsNotFoundException {
		return null;
	}

	@Override
	public List<Bill> getCustomerPostPaidAccountAllBillDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
			BillDetailsNotFoundException {
		Customer customer = customerDAOServices.findById(customerID).orElseThrow(()->
		new CustomerDetailsNotFoundException("Customer details for customerId"+customerID+"not found"));
		PostpaidAccount postpaidAccount=postpaidAccountDAOServices.findById(mobileNo).orElseThrow(()->
		new PostpaidAccountNotFoundException("Postpaid account for mobileNo"+mobileNo+"not found"));
		List<Bill>bills = billingDAOServices.findby(mobileNo);
		return bills;
	}

	@Override
	public boolean changePlan(int customerID, long mobileNo, int planID) throws CustomerDetailsNotFoundException,
	PostpaidAccountNotFoundException, PlanDetailsNotFoundException, BillingServicesDownException {
		Customer customer = customerDAOServices.findById(customerID).orElseThrow(()->
		new CustomerDetailsNotFoundException("Customer details for customerId"+customerID+"not found"));
		Plan plan = planDAOServices.findById(planID).orElseThrow(()->
		new PlanDetailsNotFoundException("Plan details for planId"+planID+"not found"));
		PostpaidAccount postpaidAccount=postpaidAccountDAOServices.findById(mobileNo).orElseThrow(()->
		new PostpaidAccountNotFoundException("Postpaid account for mobileNo"+mobileNo+"not found"));
		postpaidAccount.setPlan(plan);
		postpaidAccountDAOServices.save(postpaidAccount);
		return false;
	}

	@Override
	public boolean closeCustomerPostPaidAccount(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		Customer customer = customerDAOServices.findById(customerID).orElseThrow(()-> new CustomerDetailsNotFoundException("Customer details for customerId"+customerID+"not found"));
		PostpaidAccount postpaidAccount=postpaidAccountDAOServices.findById(mobileNo).orElseThrow(()->	new PostpaidAccountNotFoundException("Postpaid account for mobileNo"+mobileNo+"not found"));
		postpaidAccountDAOServices.deleteById(mobileNo);
		return true;
	}

	@Override
	public boolean deleteCustomer(int customerID)
			throws BillingServicesDownException, CustomerDetailsNotFoundException {
		Customer customer = customerDAOServices.findById(customerID).orElseThrow(()->
		new CustomerDetailsNotFoundException("Customer details for customerId"+customerID+"not found"));
		customerDAOServices.deleteById(customerID);
		return true;

	}

	@Override
	public Plan getCustomerPostPaidAccountPlanDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
			PlanDetailsNotFoundException {
		PostpaidAccount postpaidAccount=postpaidAccountDAOServices.findById(mobileNo).orElseThrow(()->
		new PostpaidAccountNotFoundException("Postpaid account for mobileNo"+mobileNo+"not found"));
		return postpaidAccount.getPlan();
	}
}