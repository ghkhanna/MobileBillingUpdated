package com.cg.mobilebilling.controllers;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
import com.cg.mobilebilling.services.BillingServices;

@Controller
public class CustomerController {
	@Autowired
	private BillingServices billingServices;

	@RequestMapping("registerCustomer")
	public ModelAndView registerCustomerAction(@Valid @ModelAttribute Customer customer,BindingResult result,Model model){
		if(result.hasErrors())
			return new ModelAndView("registrationPage");
		try {
			customer=billingServices.acceptCustomerDetails(customer);
			model.addAttribute("successMessage","Registration Successful. Customer ID:"+customer.getCustomerID());
			return new ModelAndView("indexPage","customer",customer);
		} catch (BillingServicesDownException| CustomerDetailsNotFoundException e) {
			model.addAttribute("errorMessage",e.getMessage());
			return new ModelAndView("indexPage");
		}					
	}


	@RequestMapping("displayPlanDetails")
	public ModelAndView displayPlanDetailsAction(@Valid @ModelAttribute Customer customer,BindingResult result,Model model) {
		try {
			List<Plan> plans = billingServices.getPlanAllDetails();
			model.addAttribute("plans",plans);		
			return new ModelAndView("displayPlansPage");
		} catch (BillingServicesDownException e) {
			model.addAttribute("errorMessage",e.getMessage());		
			return new ModelAndView("indexPage");
		}				
	}

	@RequestMapping("addPlanToAccount")
	public ModelAndView addPlanToAccountAction(@RequestParam("planID") int planID, @ModelAttribute Customer customer,Model model) {
		try {
			long mobileNo= billingServices.openPostpaidMobileAccount(customer.getCustomerID(), planID);
			model.addAttribute("successMessage", "Postpaid account successfully created. Your new mobile number is "+mobileNo);
			return new ModelAndView("indexPage");
		} catch (PlanDetailsNotFoundException | CustomerDetailsNotFoundException | BillingServicesDownException e) {
			model.addAttribute("errorMessage", e.getMessage());
			return new ModelAndView("indexPage");
		}
	}


	@RequestMapping("enterBillDetails")
	public ModelAndView enterBillDetailsAction(@Valid @ModelAttribute Bill bill, BindingResult result,Model model, 
			@RequestParam("mobileNo") long mobileNo,@RequestParam("customerID") int customerID) {
		try {
			/*float billAmount=billingServices.generateMonthlyMobileBill(customer.getCustomerID(), mobileNo, bill.getBillMonth(), bill.getNoOfLocalSMS(), bill.getNoOfStdSMS(), bill.getNoOfLocalCalls(), bill.getNoOfStdCalls(), bill.getInternetDataUsageUnits());
			return new ModelAndView("billSuccessPage","billAmount",billAmount);*/
			bill= billingServices.generateMonthlyMobileBill(customerID, mobileNo, bill.getBillMonth(), bill.getNoOfLocalSMS(), bill.getNoOfStdSMS(), bill.getNoOfLocalCalls(), bill.getNoOfStdCalls(), bill.getInternetDataUsageUnits());
			Plan plan=billingServices.getCustomerPostPaidAccountPlanDetails(customerID, mobileNo);
			model.addAttribute("bill", bill);
			model.addAttribute("plan",plan);
			return new ModelAndView("billSuccessPage");
		} catch (CustomerDetailsNotFoundException | PostpaidAccountNotFoundException | InvalidBillMonthException
				| BillingServicesDownException | PlanDetailsNotFoundException e) {
			model.addAttribute("errorMessage", e.getMessage());
			return new ModelAndView("indexPage");
		}


	}

	@RequestMapping("deleteCustomerController")
	public ModelAndView deleteCustomerAction(@Valid @ModelAttribute Customer customer, BindingResult result,Model model) {
		try {
			boolean deleteCustomer=billingServices.deleteCustomer(customer.getCustomerID());
			model.addAttribute("successMessage","Your account has been successfully deleted");
			return  new ModelAndView("indexPage");
		} catch (BillingServicesDownException |CustomerDetailsNotFoundException e) {
			model.addAttribute("errorMessage", e.getMessage());
			return new ModelAndView("indexPage");
		} 		
	}

	@RequestMapping("editPlan")
	public ModelAndView editPlanAction(@Valid @RequestParam("customerID") int customerID, @RequestParam("mobileNo") int mobileNo, @RequestParam("planID") int planID, Model model) {
		try {
			billingServices.changePlan(customerID, mobileNo, planID);
			model.addAttribute("successMessage", "Plan changed successfully for mobileNo "+mobileNo);
			return new ModelAndView("indexPage");
		} catch (CustomerDetailsNotFoundException | PostpaidAccountNotFoundException | PlanDetailsNotFoundException
				| BillingServicesDownException e) {
			model.addAttribute("errorMessage", e.getMessage());
			return new ModelAndView("indexPage");
		}

	}
	
	@RequestMapping("close")
	public ModelAndView closeAction(@Valid @RequestParam("customerID") int customerID, @RequestParam("mobileNo") int mobileNo, Model model) {
		try {
			billingServices.closeCustomerPostPaidAccount(customerID, mobileNo);
			model.addAttribute("successMessage", "Postpaid account of mobileNo: "+mobileNo+" successfully closed");
			return new ModelAndView("indexPage");
		} catch (CustomerDetailsNotFoundException | PostpaidAccountNotFoundException | BillingServicesDownException e) {
			model.addAttribute("errorMessage", e.getMessage());
			return new ModelAndView("indexPage");
		}
	}
}

