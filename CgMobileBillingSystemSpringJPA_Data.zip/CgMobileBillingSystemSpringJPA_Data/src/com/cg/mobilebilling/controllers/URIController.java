package com.cg.mobilebilling.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
@Controller
public class URIController {
	
	public URIController() {
	}	
	
	@RequestMapping("/")
	public String getIndexPage(){
		return "indexPage";
	}			
	@RequestMapping("/registration")
	public String getRegistrationPage(){
		return "registrationPage";
	}	
		
	@RequestMapping("/getMonthlyBill")
	public String getMonthlyBillPage(){
		return "getMonthlyBillPage";
	}	
	
	@RequestMapping("/deleteCustomer")
	public String getDeleteCustomerPage(){
		return "deleteCustomerPage";
	}	
	@RequestMapping("/closeAccount")
	public String getCloseAccountPage(){
		return "closeAccountPage";
	}	

	@ModelAttribute
	public Customer getCustomer() {
		return new Customer();
	}
	@ModelAttribute
	public Bill getBill() {
		return new Bill();
	}
}
